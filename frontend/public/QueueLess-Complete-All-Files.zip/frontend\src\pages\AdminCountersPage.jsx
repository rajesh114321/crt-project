import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { 
  SlidersHorizontal, 
  Power, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Building2, 
  User, 
  ShieldCheck,
  RefreshCw
} from 'lucide-react';

export const AdminCountersPage = ({ setCurrentView }) => {
  const { counters, departments, updateCounter, refreshQueue, isRefreshing } = useQueue();
  const [editingCounter, setEditingCounter] = useState(null);

  const handleStatusToggle = async (counter) => {
    const nextStatus = counter.status === 'Active' ? 'Offline' : 'Active';
    await updateCounter(counter.id || `counter_${counter.counterNumber}`, {
      status: nextStatus
    });
  };

  const handleDeptChange = async (counter, newDeptId) => {
    await updateCounter(counter.id || `counter_${counter.counterNumber}`, {
      departmentId: newDeptId
    });
  };

  const handleStaffChange = async (counter, newStaffName) => {
    await updateCounter(counter.id || `counter_${counter.counterNumber}`, {
      staffName: newStaffName
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Multi-Counter Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Activate, disable, or re-route physical desks across departments in real time.
          </p>
        </div>

        <button
          onClick={() => refreshQueue()}
          disabled={isRefreshing}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh Counters
        </button>
      </div>

      {/* Counters Grid (Section 13 Requirement) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {counters.map((c) => {
          const isActive = c.status === 'Active';

          return (
            <div
              key={c.id || c.counterNumber}
              className={`rounded-3xl border transition-all p-6 space-y-5 flex flex-col justify-between ${
                isActive
                  ? 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 shadow-xl'
                  : 'bg-slate-50 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800/80 opacity-75'
              }`}
            >
              <div className="space-y-4">
                {/* Counter Card Top */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-brand-50 dark:bg-brand-950 font-mono font-bold text-brand-600 dark:text-brand-400 flex items-center justify-center text-sm">
                      #{c.counterNumber}
                    </span>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white">
                      Counter {c.counterNumber}
                    </h3>
                  </div>

                  {/* Status Indicator */}
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold ${
                    isActive 
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                      : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}>
                    {c.status}
                  </span>
                </div>

                {/* Currently Serving Token Display */}
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
                    Current Token
                  </span>
                  <span className={`text-2xl font-black font-mono ${isActive && c.currentlyServing && c.currentlyServing !== 'None' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`}>
                    {c.currentlyServing || c.currentToken || 'None'}
                  </span>
                  <div className="text-[11px] text-slate-400 font-mono mt-1">
                    Waiting backlog: <strong className="text-slate-700 dark:text-slate-300">{c.waitingCount ?? 0} students</strong>
                  </div>
                </div>

                {/* Staff Member Assignment */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-semibold text-slate-500 uppercase font-mono">
                    Staff In-Charge
                  </label>
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    {c.staffName || 'College Staff Officer'}
                  </p>
                </div>

                {/* Department Assignment Dropdown (Section 13 Requirement) */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-semibold text-slate-500 uppercase font-mono">
                    Assigned Department
                  </label>
                  <select
                    value={c.departmentId}
                    onChange={(e) => handleDeptChange(c, e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Counter Toggle Action Button (Section 13 Requirement) */}
              <button
                type="button"
                onClick={() => handleStatusToggle(c)}
                className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  isActive
                    ? 'bg-red-50 hover:bg-red-100 text-red-700 dark:bg-red-950/40 dark:hover:bg-red-900/60 dark:text-red-300'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                }`}
              >
                <Power className="w-3.5 h-3.5" />
                {isActive ? 'Disable Counter (Go Offline)' : 'Activate Counter'}
              </button>
            </div>
          );
        })}
      </div>

    </div>
  );
};
