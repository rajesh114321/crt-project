import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { QueueProvider } from './context/QueueContext';

// Components
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Toaster } from './components/Toaster';
import { NotificationDrawer } from './components/NotificationDrawer';

// Pages
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { StudentDashboard } from './pages/StudentDashboard';
import { GetTokenPage } from './pages/GetTokenPage';
import { DigitalTokenPage } from './pages/DigitalTokenPage';
import { LiveQueuePage } from './pages/LiveQueuePage';
import { TokenHistoryPage } from './pages/TokenHistoryPage';
import { ProfilePage } from './pages/ProfilePage';
import { AdminDashboard } from './pages/AdminDashboard';
import { AdminQueuesPage } from './pages/AdminQueuesPage';
import { AdminCountersPage } from './pages/AdminCountersPage';
import { AdminServicesPage } from './pages/AdminServicesPage';
import { AdminReportsPage } from './pages/AdminReportsPage';
import { AdminAnalyticsPage } from './pages/AdminAnalyticsPage';
import { AdminSearchPage } from './pages/AdminSearchPage';
import { AboutPage } from './pages/AboutPage';
import { KioskDisplayPage } from './pages/KioskDisplayPage';

const AppContent = () => {
  const { user, isAuthenticated, isAdmin, loading } = useAuth();
  const [currentView, setCurrentView] = useState('landing');

  // If user signs in and is on landing or login, route to their relevant dashboard
  useEffect(() => {
    if (isAuthenticated) {
      if (currentView === 'login' || currentView === 'landing') {
        setCurrentView(isAdmin ? 'admin-dashboard' : 'student-dashboard');
      }
    }
  }, [isAuthenticated, isAdmin]);

  // View routing renderer
  const renderCurrentView = () => {
    switch (currentView) {
      case 'landing':
        return <LandingPage setCurrentView={setCurrentView} />;
      case 'login':
        return <LoginPage setCurrentView={setCurrentView} initialTab="login" />;
      case 'register':
        return <LoginPage setCurrentView={setCurrentView} initialTab="register" />;
      case 'student-dashboard':
        return <StudentDashboard setCurrentView={setCurrentView} />;
      case 'get-token':
        return <GetTokenPage setCurrentView={setCurrentView} />;
      case 'digital-token':
        return <DigitalTokenPage setCurrentView={setCurrentView} />;
      case 'live-queue':
        return <LiveQueuePage setCurrentView={setCurrentView} />;
      case 'token-history':
        return <TokenHistoryPage setCurrentView={setCurrentView} />;
      case 'profile':
        return <ProfilePage setCurrentView={setCurrentView} />;
      case 'admin-dashboard':
        return <AdminDashboard setCurrentView={setCurrentView} />;
      case 'admin-queues':
        return <AdminQueuesPage setCurrentView={setCurrentView} />;
      case 'admin-counters':
        return <AdminCountersPage setCurrentView={setCurrentView} />;
      case 'admin-services':
        return <AdminServicesPage setCurrentView={setCurrentView} />;
      case 'admin-reports':
        return <AdminReportsPage setCurrentView={setCurrentView} />;
      case 'admin-analytics':
        return <AdminAnalyticsPage setCurrentView={setCurrentView} />;
      case 'admin-search':
        return <AdminSearchPage setCurrentView={setCurrentView} />;
      case 'about':
        return <AboutPage setCurrentView={setCurrentView} />;
      case 'kiosk':
        return <KioskDisplayPage setCurrentView={setCurrentView} />;
      default:
        return <LandingPage setCurrentView={setCurrentView} />;
    }
  };

  if (currentView === 'kiosk') {
    return (
      <div className="min-h-screen bg-slate-950 text-white font-sans">
        <KioskDisplayPage setCurrentView={setCurrentView} />
        <Toaster />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      <Navbar currentView={currentView} setCurrentView={setCurrentView} />
      
      <main className="flex-1">
        {renderCurrentView()}
      </main>

      <Footer setCurrentView={setCurrentView} />
      <NotificationDrawer />
      <Toaster />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
          <QueueProvider>
            <AppContent />
          </QueueProvider>
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
