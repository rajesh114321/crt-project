import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useQueue } from '../context/QueueContext';
import { Modal } from '../components/Modal';
import { 
  Ticket, 
  Building2, 
  Clock, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  Search,
  School,
  BookOpen,
  Coffee,
  Coins
} from 'lucide-react';

export const GetTokenPage = ({ setCurrentView }) => {
  const { user, isAuthenticated } = useAuth();
  const { departments, activeToken, joinQueue } = useQueue();

  const [selectedDeptId, setSelectedDeptId] = useState('all');
  const [selectedService, setSelectedService] = useState(null); // { dept, service }
  const [confirmModal, setConfirmModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const getDeptIcon = (code) => {
    switch (code) {
      case 'F': return <Coins className="w-5 h-5 text-indigo-500" />;
      case 'O': return <School className="w-5 h-5 text-blue-500" />;
      case 'L': return <BookOpen className="w-5 h-5 text-emerald-500" />;
      case 'C': return <Coffee className="w-5 h-5 text-amber-500" />;
      default: return <Building2 className="w-5 h-5 text-brand-500" />;
    }
  };

  const filteredDepartments = departments.filter(d => 
    selectedDeptId === 'all' || d.id === selectedDeptId
  );

  const handleJoinClick = (dept, srv) => {
    if (!isAuthenticated) {
      setCurrentView('login');
      return;
    }
    setSelectedService({ dept, srv });
    setConfirmModal(true);
  };

  const handleConfirmJoin = async () => {
    if (!selectedService) return;
    setLoading(true);
    try {
      await joinQueue(selectedService.dept.id, selectedService.srv.name);
      setConfirmModal(false);
      setCurrentView('digital-token');
    } catch (err) {
      // Toast handles error display
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Page Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <span className="text-xs font-mono uppercase tracking-widest text-brand-600 dark:text-brand-400 font-semibold">
          Instant Queue Registration
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Select Department & Service
        </h1>
        <p className="text-sm sm:text-base text-slate-500">
          Choose a college department to join the digital queue. Your position and wait time will be computed automatically.
        </p>
      </div>

      {/* Already holding token banner */}
      {activeToken && (
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <div>
              <p className="font-semibold text-amber-900 dark:text-amber-200">
                You already hold an active token: <span className="font-mono font-bold">{activeToken.tokenNumber}</span> ({activeToken.service})
              </p>
              <p className="text-xs text-amber-700 dark:text-amber-400">
                To keep queues orderly, students can hold one active token at a time.
              </p>
            </div>
          </div>
          <button
            onClick={() => setCurrentView('digital-token')}
            className="shrink-0 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            View Active Pass →
          </button>
        </div>
      )}

      {/* Department Tabs Filter */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setSelectedDeptId('all')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            selectedDeptId === 'all'
              ? 'bg-brand-600 text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          All Departments
        </button>
        {departments.map(d => (
          <button
            key={d.id}
            onClick={() => setSelectedDeptId(d.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              selectedDeptId === d.id
                ? 'bg-brand-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            {getDeptIcon(d.code)}
            {d.name}
          </button>
        ))}
      </div>

      {/* Department & Services Sections */}
      <div className="space-y-10">
        {filteredDepartments.map((dept) => (
          <div key={dept.id} className="space-y-4">
            
            {/* Department Title Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 border border-brand-200/60 dark:border-brand-900">
                  {getDeptIcon(dept.code)}
                </div>
                <div>
                  <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                    {dept.name}
                  </h3>
                  <p className="text-xs text-slate-500">{dept.location}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="text-slate-500">
                  Currently Serving: <strong className="text-emerald-600 dark:text-emerald-400">{dept.currentlyServing}</strong>
                </span>
                <span className="text-slate-300 dark:text-slate-700">•</span>
                <span className="text-slate-500">
                  Waiting: <strong className="text-brand-600 dark:text-brand-400">{dept.waitingCount}</strong>
                </span>
              </div>
            </div>

            {/* Service Cards Grid (Sections 6 Requirement) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {dept.services.map((srv) => {
                // Calculate dynamic waiting estimate for this service
                const waitingPeople = dept.waitingCount;
                const estWait = waitingPeople * srv.estimatedMinutes;

                return (
                  <div
                    key={srv.id}
                    className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 p-5 shadow-card hover:shadow-card-hover transition-all flex flex-col justify-between space-y-4 group"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300 font-bold">
                          Code: {dept.code}
                        </span>
                        <span className="text-[11px] font-mono text-slate-400">
                          ~{srv.estimatedMinutes}m / person
                        </span>
                      </div>
                      <h4 className="font-bold text-base text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                        {srv.name}
                      </h4>
                      <p className="text-xs text-slate-500 leading-relaxed">
                        {srv.description}
                      </p>
                    </div>

                    {/* Service Live Metrics Display Required in Section 6 */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800 space-y-1.5 text-xs">
                      <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                        <span>Currently Serving:</span>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          {dept.currentlyServing}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                        <span>People Waiting:</span>
                        <span className="font-mono font-bold text-brand-600 dark:text-brand-400">
                          {waitingPeople}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                        <span>Estimated Wait:</span>
                        <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                          {estWait} min
                        </span>
                      </div>
                    </div>

                    {/* Join Queue Button */}
                    <button
                      type="button"
                      disabled={!!activeToken}
                      onClick={() => handleJoinClick(dept, srv)}
                      className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs ${
                        activeToken
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                          : 'bg-brand-600 hover:bg-brand-700 active:scale-95 text-white shadow-brand-600/20'
                      }`}
                    >
                      <Ticket className="w-4 h-4" />
                      {activeToken ? 'Token Already Active' : 'Join Queue'}
                      {!activeToken && <ArrowRight className="w-3.5 h-3.5 ml-1" />}
                    </button>
                  </div>
                );
              })}
            </div>

          </div>
        ))}
      </div>

      {/* Confirmation Modal Before Token Generation */}
      <Modal
        isOpen={confirmModal}
        onClose={() => setConfirmModal(false)}
        title="Confirm Queue Registration"
        confirmText="Confirm & Generate Token"
        loading={loading}
        onConfirm={handleConfirmJoin}
      >
        {selectedService && (
          <div className="space-y-4">
            <div className="p-3.5 rounded-xl bg-brand-50 dark:bg-brand-950/40 border border-brand-200 dark:border-brand-800 space-y-1">
              <span className="text-[11px] font-mono uppercase text-brand-600 font-bold block">
                Selected Department & Service
              </span>
              <p className="font-bold text-sm text-slate-900 dark:text-white">
                {selectedService.dept.name} • {selectedService.srv.name}
              </p>
              <p className="text-xs text-slate-500">
                Location: {selectedService.dept.location}
              </p>
            </div>

            <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex justify-between">
                <span>Student:</span>
                <span className="font-bold text-slate-900 dark:text-white">{user?.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Student ID:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{user?.studentId}</span>
              </div>
              <div className="flex justify-between">
                <span>People ahead in queue:</span>
                <span className="font-mono font-bold text-brand-600">{selectedService.dept.waitingCount}</span>
              </div>
              <div className="flex justify-between">
                <span>Expected waiting time:</span>
                <span className="font-mono font-bold text-amber-600">
                  ~ {selectedService.dept.waitingCount * selectedService.srv.estimatedMinutes} minutes
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-snug">
              By confirming, a digital token pass will be generated. You will be alerted via sound and notification when your turn approaches.
            </p>
          </div>
        )}
      </Modal>

    </div>
  );
};
