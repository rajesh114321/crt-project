import React, { useState, useEffect } from 'react';
import { useQueue } from '../context/QueueContext';
import { useAuth } from '../context/AuthContext';
import { playChime } from '../utils/audio';
import { 
  Activity, 
  RefreshCw, 
  CheckCircle2, 
  ArrowRight, 
  Volume2, 
  Clock, 
  Users, 
  AlertCircle, 
  ShieldCheck, 
  MapPin,
  Play,
  Pause
} from 'lucide-react';

export const LiveQueuePage = ({ setCurrentView }) => {
  const { isAuthenticated } = useAuth();
  const { 
    counters, 
    liveQueue, 
    departments, 
    activeToken, 
    refreshQueue, 
    isRefreshing,
    autoRefresh,
    setAutoRefresh
  } = useQueue();

  const [counterTimer, setCounterTimer] = useState(6);
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('all');

  // Countdown clock effect for real-time auto-refresh indicator
  useEffect(() => {
    if (!autoRefresh) return;
    const timer = setInterval(() => {
      setCounterTimer(prev => {
        if (prev <= 1) {
          return 6;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [autoRefresh]);

  const studentStatus = liveQueue?.studentStatus;
  const queueSteps = studentStatus?.queueSteps || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Page Header with Auto-refresh & Sound test */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-600 dark:text-emerald-400 font-semibold">
              Real-Time Remote Tracker
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Live College Queue Display
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Monitor all campus counters and your position remotely from anywhere on campus.
          </p>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {/* Auto Refresh pill */}
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              autoRefresh 
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800' 
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
            }`}
          >
            {autoRefresh ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            {autoRefresh ? `Auto-sync: ${counterTimer}s` : 'Paused'}
          </button>

          {/* Sound test button */}
          <button
            onClick={() => playChime('call')}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-brand-600 transition-colors"
            title="Test announcement bell"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          {/* Manual Refresh */}
          <button
            onClick={() => refreshQueue()}
            disabled={isRefreshing}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Multi-Counter Status Cards (Section 8 Requirement) */}
      <div className="space-y-3">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold">
          Department Counters Status
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {counters.map((c) => {
            const isOffline = c.status === 'Offline';
            return (
              <div
                key={c.counterId || c.id || c.counterNumber}
                className={`p-5 rounded-3xl border transition-all ${
                  isOffline
                    ? 'bg-slate-100/70 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
                    : 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 shadow-card hover:shadow-card-hover'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-mono font-bold text-slate-500">Counter {c.counterNumber}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold ${
                    c.status === 'Active' 
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' 
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                  }`}>
                    {c.status}
                  </span>
                </div>

                <h4 className="font-bold text-base text-slate-900 dark:text-white truncate">
                  {c.departmentName}
                </h4>
                <p className="text-xs text-slate-400 truncate">Staff: {c.staffName || 'Officer In-Charge'}</p>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-baseline justify-between">
                  <span className="text-xs text-slate-500">Currently Serving:</span>
                  <span className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                    {c.currentlyServing || 'None'}
                  </span>
                </div>

                <div className="mt-1 flex items-baseline justify-between text-xs text-slate-400 font-mono">
                  <span>Waiting in line:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    {c.waitingCount ?? 0} students
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Student's Visual Step-by-Step Queue Pipeline (Section 8 Requirement) */}
      {activeToken ? (
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-brand-600 font-bold">
                Your Department Queue Pipeline
              </span>
              <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                Queue for {activeToken.departmentName} ({activeToken.service})
              </h3>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono text-slate-400 block">Your Token</span>
              <span className="text-2xl font-black font-mono text-brand-600 dark:text-brand-400">
                {activeToken.tokenNumber}
              </span>
            </div>
          </div>

          {/* Visual Step-by-Step Flow */}
          <div className="space-y-4">
            <p className="text-xs text-slate-500">
              Live token movement from service completion to your position:
            </p>

            <div className="flex items-center gap-2 overflow-x-auto py-4 px-2">
              {queueSteps.length > 0 ? (
                queueSteps.map((step, idx) => {
                  const isDone = step.status === 'done';
                  const isServing = step.status === 'serving';
                  const isUser = step.status === 'user';
                  const isNext = step.status === 'next';

                  return (
                    <React.Fragment key={idx}>
                      <div className={`shrink-0 flex flex-col items-center p-3 rounded-2xl border min-w-[100px] text-center transition-all ${
                        isUser
                          ? 'bg-brand-600 text-white border-brand-500 shadow-lg shadow-brand-600/30 ring-2 ring-brand-400'
                          : isServing
                            ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-400 text-emerald-900 dark:text-emerald-200 shadow-md'
                            : isNext
                              ? 'bg-amber-50 dark:bg-amber-950 border-amber-300 text-amber-900 dark:text-amber-200'
                              : isDone
                                ? 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 text-slate-400'
                                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}>
                        <div className="flex items-center gap-1 font-mono font-bold text-sm">
                          <span>{step.tokenNumber}</span>
                          {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                        </div>
                        <span className={`text-[10px] font-mono mt-1 ${isUser ? 'text-brand-100 font-bold uppercase' : 'text-slate-400'}`}>
                          {step.label}
                        </span>
                      </div>

                      {idx < queueSteps.length - 1 && (
                        <ArrowRight className="w-4 h-4 text-slate-300 dark:text-slate-700 shrink-0" />
                      )}
                    </React.Fragment>
                  );
                })
              ) : (
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span className="font-mono font-bold text-emerald-600">Now Serving: {studentStatus?.currentlyServing || 'None'}</span>
                  <ArrowRight className="w-4 h-4 text-slate-300" />
                  <span className="font-mono font-bold text-brand-600">Your Token: {activeToken.tokenNumber}</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick status advice */}
          <div className="p-4 rounded-2xl bg-brand-50/70 dark:bg-brand-950/30 border border-brand-200 dark:border-brand-900/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-brand-600" />
              <span className="text-brand-950 dark:text-brand-200">
                You have <strong>{studentStatus?.peopleAhead ?? 0} students ahead</strong>. Estimated arrival at Counter {activeToken.counter || 2} in ~{studentStatus?.estimatedWaitMinutes ?? 0} minutes.
              </span>
            </div>
            <button
              onClick={() => setCurrentView('digital-token')}
              className="shrink-0 px-3.5 py-1.5 rounded-xl bg-brand-600 text-white font-semibold shadow-xs hover:bg-brand-700 transition-colors"
            >
              Open Digital Pass & QR →
            </button>
          </div>
        </div>
      ) : (
        /* Prompt to join queue */
        <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-bold text-base text-slate-900 dark:text-white">
              Want to see your token in the visual queue?
            </h4>
            <p className="text-xs text-slate-500">
              Join any department queue to get your personalized live pipeline and audio arrival alerts.
            </p>
          </div>
          <button
            onClick={() => setCurrentView('get-token')}
            className="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold shadow-md transition-colors whitespace-nowrap"
          >
            Get Digital Token Now
          </button>
        </div>
      )}

    </div>
  );
};
