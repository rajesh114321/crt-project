import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { ReceiptModal } from '../components/ReceiptModal';
import { FeedbackModal } from '../components/FeedbackModal';
import { 
  Layers, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Search, 
  Calendar,
  Building2,
  Ticket,
  FileText,
  Star
} from 'lucide-react';

export const TokenHistoryPage = ({ setCurrentView }) => {
  const { userTokens } = useQueue();
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [search, setSearch] = useState('');
  const [selectedReceiptToken, setSelectedReceiptToken] = useState(null);
  const [selectedRatingToken, setSelectedRatingToken] = useState(null);

  const filtered = userTokens.filter(t => {
    const matchesStatus = filterStatus === 'ALL' || t.status === filterStatus;
    const matchesSearch = 
      t.tokenNumber.toLowerCase().includes(search.toLowerCase()) ||
      t.service.toLowerCase().includes(search.toLowerCase()) ||
      t.departmentName.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Completed
          </span>
        );
      case 'SKIPPED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-orange-100 dark:bg-orange-950 text-orange-800 dark:text-orange-300">
            <AlertTriangle className="w-3.5 h-3.5" />
            Skipped (No-Show)
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            <XCircle className="w-3.5 h-3.5" />
            Cancelled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-brand-100 dark:bg-brand-950 text-brand-800 dark:text-brand-300">
            <Clock className="w-3.5 h-3.5" />
            {status}
          </span>
        );
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Token Activity History
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Audit record of your past college service tokens and completion timestamps.
          </p>
        </div>

        <button
          onClick={() => setCurrentView('get-token')}
          className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-xs transition-colors"
        >
          Take New Token
        </button>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by token, service, dept..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold">
          {['ALL', 'COMPLETED', 'WAITING', 'CANCELLED', 'SKIPPED'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                filterStatus === st
                  ? 'bg-brand-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* History Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="text-center py-16 px-4">
            <Ticket className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
            <h4 className="font-bold text-slate-800 dark:text-slate-200 text-sm">No tokens found</h4>
            <p className="text-xs text-slate-400 mt-1">Try adjusting your search criteria or join a queue.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-mono uppercase tracking-wider border-b border-slate-200/80 dark:border-slate-800">
                <tr>
                  <th className="py-3.5 px-5 font-semibold">Token</th>
                  <th className="py-3.5 px-4 font-semibold">Service</th>
                  <th className="py-3.5 px-4 font-semibold">Department</th>
                  <th className="py-3.5 px-4 font-semibold">Counter</th>
                  <th className="py-3.5 px-4 font-semibold">Date & Time</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-5 font-semibold text-right">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-4 px-5 font-mono font-bold text-sm text-brand-600 dark:text-brand-400">
                      {t.tokenNumber}
                    </td>
                    <td className="py-4 px-4 font-semibold text-slate-900 dark:text-white">
                      {t.service}
                    </td>
                    <td className="py-4 px-4 text-slate-600 dark:text-slate-300">
                      {t.departmentName}
                    </td>
                    <td className="py-4 px-4 font-mono font-medium text-slate-600 dark:text-slate-400">
                      Counter {t.counter || 2}
                    </td>
                    <td className="py-4 px-4 text-slate-400 font-mono">
                      {new Date(t.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })} • {new Date(t.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-4 px-4">
                      {getStatusBadge(t.status)}
                    </td>
                    <td className="py-4 px-5 text-right">
                      {t.status === 'COMPLETED' ? (
                        <div className="inline-flex items-center gap-1.5 justify-end">
                          <button
                            type="button"
                            onClick={() => setSelectedRatingToken(t)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 transition-colors"
                            title="Rate this completed service"
                          >
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            {t.rating ? `${t.rating}★` : 'Rate'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setSelectedReceiptToken(t)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 transition-colors"
                            title="View official acknowledgement receipt slip"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            Slip
                          </button>
                        </div>
                      ) : (
                        <span className="text-slate-400 font-mono text-[11px]">---</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Official College E-Receipt Slip Modal */}
      <ReceiptModal
        isOpen={!!selectedReceiptToken}
        onClose={() => setSelectedReceiptToken(null)}
        token={selectedReceiptToken}
      />

      {/* Service Rating Feedback Modal */}
      <FeedbackModal
        isOpen={!!selectedRatingToken}
        onClose={() => setSelectedRatingToken(null)}
        token={selectedRatingToken}
      />

    </div>
  );
};
