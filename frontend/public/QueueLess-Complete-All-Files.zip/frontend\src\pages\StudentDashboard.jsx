import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useQueue } from '../context/QueueContext';
import { QueueProgressBar } from '../components/QueueProgressBar';
import { WaitingTimeExplainer } from '../components/WaitingTimeExplainer';
import { Modal } from '../components/Modal';
import { FeedbackModal } from '../components/FeedbackModal';
import { 
  Ticket, 
  Clock, 
  Users, 
  MapPin, 
  RefreshCw, 
  XCircle, 
  Eye, 
  PlusCircle, 
  QrCode, 
  Layers, 
  Sparkles, 
  Calculator,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  Star
} from 'lucide-react';

export const StudentDashboard = ({ setCurrentView }) => {
  const { user } = useAuth();
  const { 
    activeToken, 
    liveQueue, 
    departments, 
    userTokens, 
    cancelToken, 
    refreshQueue, 
    isRefreshing 
  } = useQueue();

  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showFormulaModal, setShowFormulaModal] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [feedbackToken, setFeedbackToken] = useState(null);
  const [canceling, setCanceling] = useState(false);

  const studentStatus = liveQueue?.studentStatus;
  const currentlyServing = studentStatus?.currentlyServing || "None";
  const peopleAhead = studentStatus?.peopleAhead ?? 0;
  const estimatedWait = studentStatus?.estimatedWaitMinutes ?? 0;
  const isCalling = activeToken?.status === 'CALLING';

  const handleConfirmCancel = async () => {
    if (!activeToken) return;
    setCanceling(true);
    try {
      await cancelToken(activeToken.id);
      setShowCancelModal(false);
    } finally {
      setCanceling(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Welcome Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-gradient-to-r from-brand-700 to-indigo-700 rounded-3xl p-6 sm:p-8 text-white shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-widest text-brand-200 font-semibold">
              Student Portal
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="text-xs font-medium text-brand-100">Active Campus Session</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome, {user?.name?.split(' ')[0] || 'Student'} 👋
          </h1>
          <p className="text-xs sm:text-sm text-brand-100 max-w-xl">
            Student ID: <span className="font-mono font-bold text-white">{user?.studentId}</span> • Department: {user?.department || 'Computer Science'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => refreshQueue()}
            disabled={isRefreshing}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-xs font-semibold backdrop-blur-xs transition-all"
            title="Refresh Live Status"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh Status
          </button>
          {!activeToken && (
            <button
              onClick={() => setCurrentView('get-token')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white text-brand-700 hover:bg-brand-50 active:scale-95 text-xs font-bold shadow-md transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              Get Token
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Active Token & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column (7 cols): Active Token Card (or Empty State) */}
        <div className="lg:col-span-7 space-y-6">
          {activeToken ? (
            /* Active Token Hero Card (Section 5 Requirement) */
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden">
              
              {/* Card Header */}
              <div className={`p-6 text-white ${
                isCalling 
                  ? 'bg-gradient-to-r from-emerald-600 to-green-600' 
                  : 'bg-gradient-to-r from-brand-600 to-indigo-600'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
                      <Ticket className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-mono uppercase tracking-widest text-brand-100 font-semibold">
                        Active Queue Token
                      </span>
                      <h3 className="font-bold text-lg leading-tight">{activeToken.departmentName}</h3>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider ${
                    isCalling 
                      ? 'bg-white text-emerald-700 animate-pulse' 
                      : 'bg-brand-500/80 text-white'
                  }`}>
                    {activeToken.status}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 space-y-6">
                
                {/* Big Token Number & Service */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold block">
                      Token Number
                    </span>
                    <span className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                      {activeToken.tokenNumber}
                    </span>
                    <p className="text-sm font-semibold text-brand-600 dark:text-brand-400 mt-1">
                      {activeToken.service}
                    </p>
                  </div>

                  <div className="text-right">
                    <button
                      onClick={() => setCurrentView('digital-token')}
                      className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300 border border-brand-200 dark:border-brand-800 text-xs font-semibold hover:bg-brand-100 transition-colors"
                    >
                      <QrCode className="w-4 h-4" />
                      View QR Pass
                    </button>
                  </div>
                </div>

                {/* Key Numbers Grid Required in Section 5 */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  
                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
                      Currently Serving
                    </span>
                    <span className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
                      {currentlyServing}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
                      People Ahead
                    </span>
                    <span className="text-xl font-bold font-mono text-brand-600 dark:text-brand-400">
                      {isCalling ? 0 : peopleAhead}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
                      Estimated Waiting
                    </span>
                    <span className="text-xl font-bold font-mono text-slate-900 dark:text-slate-100">
                      {isCalling ? '0 min' : `${estimatedWait} min`}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
                      Counter
                    </span>
                    <span className="text-xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
                      Counter {activeToken.counter || 2}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <QueueProgressBar 
                  status={activeToken.status} 
                  peopleAhead={isCalling ? 0 : peopleAhead} 
                  counter={activeToken.counter || 2} 
                />

                {/* Waiting time algorithm calculation shortcut */}
                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    Formula: {peopleAhead} people × ~3 min/person
                  </span>
                  <button
                    onClick={() => setShowFormulaModal(true)}
                    className="text-brand-600 dark:text-brand-400 hover:underline flex items-center gap-1 font-medium"
                  >
                    <Calculator className="w-3 h-3" />
                    How is this calculated?
                  </button>
                </div>

                {/* Action Buttons Required in Section 5 */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setShowCancelModal(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                    >
                      <XCircle className="w-4 h-4" />
                      Cancel Token
                    </button>
                    <button
                      onClick={() => refreshQueue()}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Refresh
                    </button>
                    <button
                      onClick={() => {
                        setFeedbackToken(activeToken);
                        setShowFeedbackModal(true);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-amber-600 hover:text-amber-700 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                      title="Rate Service & Counter Experience"
                    >
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      Rate Service
                    </button>
                  </div>

                  <button
                    onClick={() => setCurrentView('live-queue')}
                    className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold shadow-md shadow-brand-600/20 active:scale-95 transition-all"
                  >
                    <Eye className="w-4 h-4" />
                    View Live Queue
                  </button>
                </div>
              </div>

            </div>
          ) : (
            /* Empty State: No active token */
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 p-8 sm:p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 mx-auto flex items-center justify-center">
                <Ticket className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-xl text-slate-900 dark:text-white">
                  You Don't Have an Active Token
                </h3>
                <p className="text-sm text-slate-500 max-w-md mx-auto">
                  Need to visit Accounts, College Office, Library, or Canteen? Take a digital token now to secure your spot.
                </p>
              </div>
              <button
                onClick={() => setCurrentView('get-token')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm shadow-md shadow-brand-600/25 active:scale-95 transition-all"
              >
                <PlusCircle className="w-4 h-4" />
                Select Department & Join Queue
              </button>
            </div>
          )}

          {/* College Campus Counter Status Ticker */}
          <div className="p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/80 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-800 dark:text-slate-200 font-mono uppercase tracking-wider">
                Current Counter Load
              </span>
              <button
                onClick={() => setCurrentView('live-queue')}
                className="text-brand-600 hover:underline font-medium"
              >
                View all →
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              {departments.map(dept => (
                <div key={dept.id} className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60">
                  <p className="font-semibold text-slate-900 dark:text-white truncate">{dept.name}</p>
                  <p className="text-[11px] text-slate-500 font-mono mt-0.5">Serving: <span className="font-bold text-emerald-600">{dept.currentlyServing}</span></p>
                  <p className="text-[11px] text-slate-400 font-mono">{dept.waitingCount} waiting</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Quick Launch Services & Token History */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Service Shortcuts */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Available Departments
              </h3>
              <span className="text-xs font-mono text-slate-400">4 Active</span>
            </div>

            <div className="space-y-2.5">
              {departments.map((dept) => (
                <div
                  key={dept.id}
                  onClick={() => setCurrentView('get-token')}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60 hover:border-brand-500 hover:bg-brand-50/30 dark:hover:bg-brand-950/20 transition-all cursor-pointer group flex items-center justify-between"
                >
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-brand-600 transition-colors">
                      {dept.name}
                    </h4>
                    <p className="text-xs text-slate-500 line-clamp-1">{dept.location}</p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] font-mono text-slate-400">
                      <span>Wait: ~{dept.estimatedWaitMinutes} min</span>
                      <span>•</span>
                      <span>{dept.services?.length || 3} services</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-brand-600 group-hover:translate-x-1 transition-all" />
                </div>
              ))}
            </div>
          </div>

          {/* Recent Token History Preview */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-brand-500" />
                Recent History
              </h3>
              <button
                onClick={() => setCurrentView('token-history')}
                className="text-xs font-semibold text-brand-600 hover:underline"
              >
                View All
              </button>
            </div>

            {userTokens.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4">No past token records.</p>
            ) : (
              <div className="space-y-2">
                {userTokens.slice(0, 3).map((tok) => (
                  <div
                    key={tok.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-900 dark:text-white">{tok.tokenNumber}</span>
                        <span className="text-[11px] text-slate-500">• {tok.service}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {new Date(tok.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {tok.status === 'COMPLETED' && (
                        <button
                          onClick={() => {
                            setFeedbackToken(tok);
                            setShowFeedbackModal(true);
                          }}
                          className="p-1 rounded-md text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors"
                          title="Rate this completed service"
                        >
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                        </button>
                      )}
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        tok.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                        tok.status === 'CANCELLED' ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {tok.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Confirmation Modal for Token Cancellation */}
      <Modal
        isOpen={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        title="Cancel Digital Token"
        confirmText="Yes, Cancel Token"
        confirmVariant="danger"
        loading={canceling}
        onConfirm={handleConfirmCancel}
      >
        <div className="space-y-3">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 text-xs">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <p>
              Are you sure you want to cancel token <strong className="font-mono">{activeToken?.tokenNumber}</strong>? You will lose your current position in the queue.
            </p>
          </div>
          <p className="text-xs text-slate-500">
            You will need to take a fresh token if you still require service at {activeToken?.departmentName}.
          </p>
        </div>
      </Modal>

      {/* Waiting Time Explainer Modal */}
      {showFormulaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={() => setShowFormulaModal(false)} />
          <div className="relative z-10 w-full max-w-xl">
            <WaitingTimeExplainer
              peopleAhead={peopleAhead}
              avgServiceTime={3}
              departmentName={activeToken?.departmentName}
              onClose={() => setShowFormulaModal(false)}
            />
          </div>
        </div>
      )}

      {/* 5-Star Feedback & Rating Modal */}
      <FeedbackModal
        isOpen={showFeedbackModal}
        onClose={() => {
          setShowFeedbackModal(false);
          setFeedbackToken(null);
        }}
        token={feedbackToken || activeToken}
      />

    </div>
  );
};
