const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const store = require('../services/store');
const { JWT_SECRET } = require('../middleware/authMiddleware');

const generateToken = (user) => {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// @desc    Register a new student
// @route   POST /api/auth/register
const register = async (req, res, next) => {
  try {
    const { name, studentId, email, phone, password, department } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide name, email, and password.' });
    }

    const existingUser = store.getUserByEmailOrStudentId(email) || (studentId ? store.getUserByEmailOrStudentId(studentId) : null);
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'A user with this email or Student ID already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const newUser = store.createUser({
      name,
      studentId: studentId || `STU-${Date.now().toString().slice(-4)}`,
      email,
      phone: phone || '',
      passwordHash,
      role: 'student',
      department: department || 'General Studies'
    });

    const token = generateToken(newUser);
    const { passwordHash: _, plainDemoPassword: __, ...safeUser } = newUser;

    res.status(201).json({
      success: true,
      user: safeUser,
      token,
      message: 'Registration successful'
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Login user (email or studentId)
// @route   POST /api/auth/login
const login = async (req, res, next) => {
  try {
    const { identifier, password } = req.body;

    if (!identifier || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email/student ID and password.' });
    }

    const user = store.getUserByEmailOrStudentId(identifier);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials. User not found.' });
    }

    // Check password (matches bcrypt hash or plain demo password)
    let isMatch = false;
    if (user.plainDemoPassword && user.plainDemoPassword === password) {
      isMatch = true;
    } else if (user.passwordHash) {
      isMatch = await bcrypt.compare(password, user.passwordHash);
    }

    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = generateToken(user);
    const { passwordHash: _, plainDemoPassword: __, ...safeUser } = user;

    res.json({
      success: true,
      user: safeUser,
      token,
      message: 'Login successful'
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Quick 1-Click Demo Login (student or admin)
// @route   POST /api/auth/demo-login
const demoLogin = (req, res, next) => {
  try {
    const { role } = req.body; // 'student' or 'admin'
    const targetEmail = role === 'admin' ? 'admin@queueless.com' : 'student@queueless.com';
    const user = store.getUserByEmailOrStudentId(targetEmail);

    if (!user) {
      return res.status(404).json({ success: false, message: 'Demo user not found' });
    }

    const token = generateToken(user);
    const { passwordHash: _, plainDemoPassword: __, ...safeUser } = user;

    res.json({
      success: true,
      user: safeUser,
      token,
      message: `Signed in as Demo ${role === 'admin' ? 'Admin' : 'Student'}`
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get Current User Profile
// @route   GET /api/auth/me
const getMe = (req, res) => {
  res.json({
    success: true,
    user: req.user
  });
};

// @desc    Update User Profile
// @route   PUT /api/auth/profile
const updateProfile = (req, res, next) => {
  try {
    const { name, phone, department } = req.body;
    const updated = store.updateUser(req.user.id, {
      ...(name && { name }),
      ...(phone !== undefined && { phone }),
      ...(department && { department })
    });

    if (!updated) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const { passwordHash: _, plainDemoPassword: __, ...safeUser } = updated;
    res.json({
      success: true,
      user: safeUser,
      message: 'Profile updated successfully'
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  register,
  login,
  demoLogin,
  getMe,
  updateProfile
};
