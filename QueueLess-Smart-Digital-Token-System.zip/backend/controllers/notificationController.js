const store = require('../services/store');

const getUserNotifications = (req, res) => {
  const notifs = store.getNotificationsByUser(req.user.id);
  res.json({
    success: true,
    data: notifs
  });
};

const markAsRead = (req, res) => {
  const notif = store.markNotificationRead(req.params.id);
  res.json({
    success: true,
    data: notif
  });
};

const markAllAsRead = (req, res) => {
  store.markAllNotificationsRead(req.user.id);
  res.json({
    success: true,
    message: 'All notifications marked as read'
  });
};

module.exports = {
  getUserNotifications,
  markAsRead,
  markAllAsRead
};
