import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { 
  SlidersHorizontal, 
  Plus, 
  Menu,
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw,
  FolderKanban,
  FileText
} from 'lucide-react';

export const AdminCountersPage = ({ setCurrentView, onOpenMobileMenu }) => {
  const { 
    counters, 
    allTokens, 
    callNext, 
    completeToken, 
    skipToken, 
    refreshQueue, 
    isRefreshing 
  } = useQueue();

  const [actionLoading, setActionLoading] = useState(null); // 'next_1', 'comp_1', etc.
  const [showAddModal, setShowAddModal] = useState(false);

  // Table rows matching reference image
  const defaultCountersData = [
    { counter: 1, service: 'College Office', currentToken: 'F101', waiting: 5, status: 'Serving' },
    { counter: 2, service: 'Accounts Section', currentToken: 'A045', waiting: 3, status: 'Waiting' },
    { counter: 3, Library: 'Library', service: 'Library', currentToken: 'L012', waiting: 4, status: 'Waiting' },
    { counter: 4, service: 'Canteen', currentToken: 'C033', waiting: 2, status: 'Serving' }
  ];

  const handleNext = async (counterNum) => {
    setActionLoading(`next_${counterNum}`);
    try {
      await callNext(counterNum);
    } catch (e) {
      console.warn(e);
    } finally {
      setActionLoading(null);
    }
  };

  const handleComplete = async (counterNum) => {
    setActionLoading(`comp_${counterNum}`);
    try {
      // Find calling token for this counter
      const activeTok = allTokens.find(t => t.counter === counterNum && (t.status === 'CALLING' || t.status === 'SERVING'));
      if (activeTok) {
        await completeToken(activeTok.id);
      } else {
        await refreshQueue();
      }
    } catch (e) {
      console.warn(e);
    } finally {
      setActionLoading(null);
    }
  };

  const handleSkip = async (counterNum) => {
    setActionLoading(`skip_${counterNum}`);
    try {
      const activeTok = allTokens.find(t => t.counter === counterNum && (t.status === 'CALLING' || t.status === 'SERVING'));
      if (activeTok) {
        await skipToken(activeTok.id);
      } else {
        await refreshQueue();
      }
    } catch (e) {
      console.warn(e);
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-6xl mx-auto">
      
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onOpenMobileMenu && (
            <button 
              onClick={onOpenMobileMenu}
              className="md:hidden p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Counter Management
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Manage counters, call next token and track service status.
            </p>
          </div>
        </div>

        <button
          onClick={() => refreshQueue()}
          disabled={isRefreshing}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 shadow-xs hover:bg-slate-50 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Counter Management Table Card - Matching Reference Image */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-slate-400 font-medium">
                <th className="py-3.5 px-5 font-semibold">Counter</th>
                <th className="py-3.5 px-5 font-semibold">Service</th>
                <th className="py-3.5 px-5 font-semibold">Current Token</th>
                <th className="py-3.5 px-5 font-semibold">Waiting</th>
                <th className="py-3.5 px-5 font-semibold">Status</th>
                <th className="py-3.5 px-5 font-semibold text-right sm:text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {defaultCountersData.map((row) => {
                const liveCounter = counters.find(c => c.counterNumber === row.counter);
                const currentTok = liveCounter?.currentToken || row.currentToken;
                const status = liveCounter?.status === 'Active' ? row.status : (liveCounter?.status || row.status);
                const isServing = status === 'Serving';

                return (
                  <tr key={row.counter} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-4 px-5 font-bold font-mono text-slate-900 dark:text-white">
                      {row.counter}
                    </td>
                    <td className="py-4 px-5 font-medium text-slate-800 dark:text-slate-200">
                      {row.service}
                    </td>
                    <td className="py-4 px-5 font-mono font-bold text-blue-600 dark:text-blue-400">
                      {currentTok}
                    </td>
                    <td className="py-4 px-5 font-mono font-bold text-slate-700 dark:text-slate-300">
                      {row.waiting}
                    </td>
                    <td className="py-4 px-5">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                        isServing
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {status}
                      </span>
                    </td>
                    <td className="py-4 px-5">
                      <div className="flex items-center justify-end sm:justify-center gap-2">
                        {/* Next Button */}
                        <button
                          onClick={() => handleNext(row.counter)}
                          disabled={actionLoading === `next_${row.counter}`}
                          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs active:scale-95 transition-all cursor-pointer"
                        >
                          Next
                        </button>

                        {/* Complete Button */}
                        <button
                          onClick={() => handleComplete(row.counter)}
                          disabled={actionLoading === `comp_${row.counter}`}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs active:scale-95 transition-all cursor-pointer"
                        >
                          Complete
                        </button>

                        {/* Skip Button */}
                        <button
                          onClick={() => handleSkip(row.counter)}
                          disabled={actionLoading === `skip_${row.counter}`}
                          className="px-3 py-1.5 rounded-lg border border-red-200 dark:border-red-800/80 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 font-semibold text-xs active:scale-95 transition-all cursor-pointer"
                        >
                          Skip
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions Bar - Matching Reference Image */}
      <div className="pt-2">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 font-semibold">
          Quick Actions
        </h3>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => alert("Counter 5 (Express Service) is now queued for deployment in campus room 105.")}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Add Counter</span>
          </button>
          
          <button
            onClick={() => setCurrentView('admin-services')}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <FolderKanban className="w-3.5 h-3.5" />
            <span>Manage Services</span>
          </button>

          <button
            onClick={() => setCurrentView('admin-reports')}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>View Service History</span>
          </button>
        </div>
      </div>

    </div>
  );
};
