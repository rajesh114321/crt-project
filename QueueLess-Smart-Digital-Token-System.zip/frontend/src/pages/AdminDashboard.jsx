import React from 'react';
import { useQueue } from '../context/QueueContext';
import { useAuth } from '../context/AuthContext';
import { 
  Ticket, 
  Users, 
  CheckCircle2, 
  Clock, 
  Menu,
  RefreshCw,
  ShieldCheck
} from 'lucide-react';

export const AdminDashboard = ({ setCurrentView, onOpenMobileMenu }) => {
  const { user } = useAuth();
  const { counters, allTokens, refreshQueue, isRefreshing } = useQueue();

  // Metrics matching reference image
  const totalToday = 124;
  const waitingTokens = 18;
  const completedTokens = 102;
  const avgServiceTime = '7 min';

  // Queue Status by Counter data matching reference image
  const counterRows = [
    { counter: 1, service: 'College Office', currentToken: 'F101', waiting: 5, status: 'Serving' },
    { counter: 2, service: 'Accounts Section', currentToken: 'A045', waiting: 5, status: 'Waiting' },
    { counter: 3, service: 'Library', currentToken: 'L012', waiting: 4, status: 'Waiting' },
    { counter: 4, service: 'Canteen', currentToken: 'C033', waiting: 2, status: 'Serving' }
  ];

  // Service Statistics Donut data matching reference image
  const donutData = [
    { name: 'College Office', percent: 30, color: '#3b82f6' },
    { name: 'Accounts', percent: 24, color: '#6366f1' },
    { name: 'Library', percent: 22, color: '#06b6d4' },
    { name: 'Canteen', percent: 24, color: '#10b981' }
  ];

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      
      {/* Top Header Row with Admin Avatar on Right */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {onOpenMobileMenu && (
            <button 
              onClick={onOpenMobileMenu}
              className="md:hidden p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Admin Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Overview of queue and service performance.
            </p>
          </div>
        </div>

        {/* Top Right Admin Profile Badge - Matching Reference Image */}
        <div className="flex items-center gap-3 bg-white dark:bg-slate-900 px-4 py-2 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 text-white font-bold flex items-center justify-center text-xs">
            {user?.name?.charAt(0) || 'A'}
          </div>
          <div className="text-left text-xs">
            <span className="font-bold text-slate-900 dark:text-white block">
              {user?.name || 'Admin'}
            </span>
            <span className="text-[11px] text-slate-400">
              Admin / Staff
            </span>
          </div>
        </div>
      </div>

      {/* 4 KPI Statistic Cards - Matching Reference Image */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Total Tokens Today */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block mb-1 font-medium">Total Tokens Today</span>
            <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900 dark:text-white">
              {totalToday}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
            <Ticket className="w-5 h-5" />
          </div>
        </div>

        {/* Waiting Tokens */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block mb-1 font-medium">Waiting Tokens</span>
            <span className="text-2xl sm:text-3xl font-black font-mono text-amber-500">
              {waitingTokens}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-500 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Completed Tokens */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block mb-1 font-medium">Completed Tokens</span>
            <span className="text-2xl sm:text-3xl font-black font-mono text-emerald-500">
              {completedTokens}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-500 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Average Service Time */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block mb-1 font-medium">Average Service Time</span>
            <span className="text-2xl sm:text-3xl font-black font-mono text-purple-600 dark:text-purple-400">
              {avgServiceTime}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-500 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Lower Section: 2 Columns (Queue Status by Counter & Service Statistics) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left: Queue Status by Counter Table - Matching Reference Image */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Queue Status by Counter
            </h2>
            <button
              onClick={() => setCurrentView('admin-counters')}
              className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold"
            >
              Manage Counters →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-medium">
                  <th className="pb-3 font-semibold">Counter</th>
                  <th className="pb-3 font-semibold">Service</th>
                  <th className="pb-3 font-semibold">Current Token</th>
                  <th className="pb-3 font-semibold">Waiting</th>
                  <th className="pb-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {counterRows.map((row) => (
                  <tr key={row.counter} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="py-3.5 font-bold font-mono text-slate-900 dark:text-white">
                      {row.counter}
                    </td>
                    <td className="py-3.5 font-medium text-slate-800 dark:text-slate-200">
                      {row.service}
                    </td>
                    <td className="py-3.5 font-mono font-bold text-blue-600 dark:text-blue-400">
                      {row.currentToken}
                    </td>
                    <td className="py-3.5 font-bold font-mono text-slate-700 dark:text-slate-300">
                      {row.waiting}
                    </td>
                    <td className="py-3.5">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                        row.status === 'Serving'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Service Statistics Donut Chart Card - Matching Reference Image */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-5">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Service Statistics
          </h2>

          {/* SVG Donut Chart */}
          <div className="flex items-center justify-center py-2">
            <div className="relative w-44 h-44">
              <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                {/* Segment 1: College Office (30%) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#3b82f6"
                  strokeWidth="16"
                  strokeDasharray="71.6 238.8"
                  strokeDashoffset="0"
                />
                {/* Segment 2: Accounts (24%) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#6366f1"
                  strokeWidth="16"
                  strokeDasharray="57.3 238.8"
                  strokeDashoffset="-71.6"
                />
                {/* Segment 3: Library (22%) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#06b6d4"
                  strokeWidth="16"
                  strokeDasharray="52.5 238.8"
                  strokeDashoffset="-128.9"
                />
                {/* Segment 4: Canteen (24%) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#10b981"
                  strokeWidth="16"
                  strokeDasharray="57.4 238.8"
                  strokeDashoffset="-181.4"
                />
              </svg>
              {/* Inner Circle cutout */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Total</span>
                <span className="text-xl font-black font-mono text-slate-900 dark:text-white">100%</span>
              </div>
            </div>
          </div>

          {/* Legend Grid Matching Reference Image */}
          <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
            {donutData.map((d) => (
              <div key={d.name} className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center gap-2 truncate">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                  <span className="text-slate-600 dark:text-slate-300 truncate font-medium">{d.name}</span>
                </div>
                <span className="font-bold font-mono text-slate-900 dark:text-white shrink-0">{d.percent}%</span>
              </div>
            ))}
          </div>

        </div>

      </div>

    </div>
  );
};
