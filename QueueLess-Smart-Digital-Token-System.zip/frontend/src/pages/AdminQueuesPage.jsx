import React, { useState } from 'react';
import { useQueue } from '../context/QueueContext';
import { playChime } from '../utils/audio';
import { Modal } from '../components/Modal';
import { CounterScannerModal } from '../components/CounterScannerModal';
import { 
  Layers, 
  PhoneCall, 
  CheckCircle2, 
  AlertTriangle, 
  RotateCcw, 
  ArrowRight, 
  Clock, 
  User, 
  RefreshCw, 
  Search, 
  Volume2,
  QrCode
} from 'lucide-react';

export const AdminQueuesPage = ({ setCurrentView }) => {
  const { 
    departments, 
    counters, 
    allTokens, 
    callNext, 
    completeToken, 
    skipToken, 
    recallToken, 
    refreshQueue, 
    isRefreshing 
  } = useQueue();

  const [activeDeptTab, setActiveDeptTab] = useState('all');
  const [skipModalToken, setSkipModalToken] = useState(null);
  const [skipping, setSkipping] = useState(false);
  const [showScannerModal, setShowScannerModal] = useState(false);

  const filteredDepts = departments.filter(d => 
    activeDeptTab === 'all' || d.id === activeDeptTab
  );

  const handleSkipConfirm = async () => {
    if (!skipModalToken) return;
    setSkipping(true);
    try {
      await skipToken(skipModalToken.id, true);
      setSkipModalToken(null);
    } finally {
      setSkipping(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Queue Dispatch & Token Controls
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Real-time staff station for calling, completing, skipping (no-show), and recalling student tokens.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowScannerModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors"
            title="Scan student QR barcode pass"
          >
            <QrCode className="w-3.5 h-3.5" />
            Scan Token QR
          </button>
          <button
            onClick={() => playChime('call')}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-brand-600"
            title="Test Chime Sound"
          >
            <Volume2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => refreshQueue()}
            disabled={isRefreshing}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh Queues
          </button>
        </div>
      </div>

      {/* Department Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveDeptTab('all')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            activeDeptTab === 'all'
              ? 'bg-brand-600 text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          All Departments
        </button>
        {departments.map(d => (
          <button
            key={d.id}
            onClick={() => setActiveDeptTab(d.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeDeptTab === d.id
                ? 'bg-brand-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            <span>{d.name}</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
              {d.waitingCount}
            </span>
          </button>
        ))}
      </div>

      {/* Queues List Per Department */}
      <div className="space-y-8">
        {filteredDepts.map((dept) => {
          const deptTokens = allTokens.filter(t => t.departmentId === dept.id);
          const callingToken = deptTokens.find(t => t.status === 'CALLING');
          const waitingList = deptTokens
            .filter(t => t.status === 'WAITING')
            .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
          const completedList = deptTokens
            .filter(t => t.status === 'COMPLETED')
            .slice(-3);
          const counter = counters.find(c => c.departmentId === dept.id);

          return (
            <div
              key={dept.id}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden"
            >
              {/* Dept Header */}
              <div className="p-5 sm:p-6 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-brand-100 dark:bg-brand-950 text-brand-700 dark:text-brand-300">
                      Code: {dept.code}
                    </span>
                    <h3 className="font-bold text-lg text-slate-900 dark:text-white">
                      {dept.name}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Assigned to Counter {counter?.counterNumber || 1} • {dept.location}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => callNext(dept.id, counter?.counterNumber || 1)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 active:scale-95 text-white text-xs font-bold shadow-md shadow-brand-600/20 transition-all"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    Call Next Token
                  </button>
                </div>
              </div>

              {/* Department Body */}
              <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Currently Called / Serving Token (Left 5 Cols) */}
                <div className="lg:col-span-5 space-y-3">
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold block">
                    Desk Station • Counter {counter?.counterNumber || 1}
                  </span>

                  {callingToken ? (
                    <div className="p-5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800/80 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                          NOW SERVING AT DESK
                        </span>
                        <span className="text-xs font-mono text-slate-400">
                          Called {new Date(callingToken.calledAt || callingToken.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div>
                        <div className="text-4xl font-black font-mono text-emerald-900 dark:text-emerald-100">
                          {callingToken.tokenNumber}
                        </div>
                        <p className="font-semibold text-sm text-slate-900 dark:text-white mt-1">
                          {callingToken.service}
                        </p>
                        <p className="text-xs text-slate-500">
                          Student: <strong className="text-slate-800 dark:text-slate-200">{callingToken.studentName}</strong> ({callingToken.studentId})
                        </p>
                      </div>

                      {/* Station Actions (Section 12 & 14 Requirements) */}
                      <div className="pt-2 border-t border-emerald-200/80 dark:border-emerald-800/60 flex flex-wrap gap-2">
                        {/* Complete Button */}
                        <button
                          type="button"
                          onClick={() => completeToken(callingToken.id)}
                          className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1.5"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Complete Token
                        </button>

                        {/* Skip Button (No-Show) */}
                        <button
                          type="button"
                          onClick={() => setSkipModalToken(callingToken)}
                          className="flex-1 py-2 px-3 rounded-xl bg-orange-600 hover:bg-orange-700 active:scale-95 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1.5"
                          title="If student is missing, skips and advances queue"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                          Skip (No-Show)
                        </button>

                        {/* Recall Button */}
                        <button
                          type="button"
                          onClick={() => recallToken(callingToken.id)}
                          className="py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 text-slate-700 dark:text-slate-200 font-semibold text-xs transition-all flex items-center gap-1"
                          title="Re-broadcast chime"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          Recall
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-2">
                      <Clock className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto" />
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">Desk Currently Idle</p>
                      <p className="text-[11px] text-slate-400">Click "Call Next Token" to begin serving the queue.</p>
                    </div>
                  )}
                </div>

                {/* Waiting Backlog Pipeline (Right 7 Cols) */}
                <div className="lg:col-span-7 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold">
                      Waiting Queue ({waitingList.length} students)
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Estimated Backlog: ~{waitingList.length * dept.avgServiceTimeMinutes}m
                    </span>
                  </div>

                  {waitingList.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 text-center text-xs text-slate-400">
                      No students waiting in this department queue.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                      {waitingList.map((tok, index) => (
                        <div
                          key={tok.id}
                          className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between text-xs hover:border-brand-500 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <span className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-700 font-mono font-bold text-slate-700 dark:text-slate-300 flex items-center justify-center text-[11px]">
                              {index + 1}
                            </span>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-slate-900 dark:text-white">
                                  {tok.tokenNumber}
                                </span>
                                <span className="text-[11px] text-brand-600 dark:text-brand-400 font-medium">
                                  {tok.service}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400">
                                {tok.studentName} ({tok.studentId})
                              </p>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="text-[11px] font-mono text-slate-400">
                              Wait: ~{(index + 1) * dept.avgServiceTimeMinutes}m
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            </div>
          );
        })}
      </div>

      {/* Skip Confirmation Modal (Section 14 Requirement) */}
      <Modal
        isOpen={!!skipModalToken}
        onClose={() => setSkipModalToken(null)}
        title="Confirm Student No-Show (Skip Token)"
        confirmText="Skip Token & Advance Queue"
        confirmVariant="danger"
        loading={skipping}
        onConfirm={handleSkipConfirm}
      >
        <div className="space-y-3">
          <div className="p-3 rounded-xl bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-900 text-xs text-orange-900 dark:text-orange-200">
            <p className="font-semibold mb-1">
              Mark Token <span className="font-mono">{skipModalToken?.tokenNumber}</span> as Skipped?
            </p>
            <p className="text-orange-700 dark:text-orange-300">
              The student did not report to the counter. This action will mark them as No-Show and automatically call the next student in line to keep the line moving smoothly.
            </p>
          </div>
        </div>
      </Modal>

      {/* Counter QR Code Scanner Simulator Modal */}
      <CounterScannerModal
        isOpen={showScannerModal}
        onClose={() => setShowScannerModal(false)}
      />

    </div>
  );
};
